const mailElement = document.getElementById("mail");

mailElement.addEventListener("mouseover", function() {
    mailElement.src = "Asserts/mail-1.png";
});

mailElement.addEventListener("mouseout", function() {
    mailElement.src = "Asserts/mail-0.png";
});
const linkedinElement = document.getElementById("linkedin");

linkedinElement.addEventListener("mouseover", function() {
    linkedinElement.src = "Asserts/linkedin-1.png";
});

linkedinElement.addEventListener("mouseout", function() {
    linkedinElement.src = "Asserts/linkedin-0.png";
});
const facebookElement = document.getElementById("facebook");

facebookElement.addEventListener("mouseover", function() {
    facebookElement.src = "Asserts/facebook-1.png";
});

facebookElement.addEventListener("mouseout", function() {
    facebookElement.src = "Asserts/facebook-0.png";
});
const instagramElement = document.getElementById("instagram");

instagramElement.addEventListener("mouseover", function() {
    instagramElement.src = "Asserts/instagram-1.png";
});

instagramElement.addEventListener("mouseout", function() {
    instagramElement.src = "Asserts/instagram-0.png";
});